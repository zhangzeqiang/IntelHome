#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>
#include <pthread.h>
#include <malloc.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/ioctl.h>
#include <stdarg.h>
#include <fcntl.h>
#include <fcntl.h>
#include <pthread.h>
#include <sys/select.h>
#include <sys/time.h>
#include "include/myType.h"
#include "include/protocol.h"
#include "module/module_433.h"

int main(){
	/*struct timeval t;
	t.tv_sec = REFRESH_TIME_SEC;
	t.tv_usec = 0;
	select(0, NULL, NULL, NULL, &t);*/		//定时器
	unsigned int _433_devno = 0;
	unsigned int _433_state = 0;
	char ch;
	//-------------------------------------------		
	//open device --- TODO
	int fd_433 = open_433(_433_FILE2);
	if (fd_433 < 0){
	//------------------------------------------
		perror("open device error!\n");
		//close device
		goto close_device;
	}

	while (1){
		scanf("%d%d", &_433_devno, &_433_state);
		
		//--------------------------------------------
		//add device refresh func...------TODO
		//---------------------------------------------------
		//1、add 433 wireless refresh func
		struct dev_node dev_433;
		int result;
		int i = 0;
		int j = 0;
		while(1){
			dev_433.devno = (unsigned short)_433_devno/*_433_MULTICALL*/;			//all 433 module
			dev_433.state = (unsigned short)_433_state/*_433_RETURNINFO*/;		//cmd to return its info
			ioctl_433(fd_433, &dev_433, 1);			//send control cmd
		
			i = 0;
	read_again:
			if ((result = readInfo_433(fd_433, &dev_433, 1)) <= 0){
				i++;
				for(j=0;j<30000;j++);			//小延时
				if (i > 500){				//超时退出
					goto read_fail;
				}
				goto read_again;
			}else{
				goto read_success;
			}
		}
	read_fail:

		printf("send --- devno:%d, state:%d\n", (unsigned short)_433_devno, (unsigned short)_433_state);
		printf("fail to read data!\n");
		goto out;

	read_success:

		printf("send --- devno:%d, state:%d\n", (unsigned short)_433_devno, (unsigned short)_433_state);
		printf("receive --- devno:%d, state:%d\n", (unsigned short)dev_433.devno, (unsigned short)dev_433.state);

	out:
		while ((ch=getchar()) != '\n' && ch != EOF);
	}
close_device:
	//--------------------------------------------
	//close device --- TODO
	close(fd_433);
	return 0;
}

